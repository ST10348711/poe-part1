/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject17;

import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class Mavenproject17 {

    public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);

        // User details (replace with actual user input)
        String username;
        String password;
        String firstName;
        String lastName;

        // Registration loop
        do {
            System.out.println("\n** Registration **");

            System.out.print("Enter username (alphanumeric, 5-15 characters): ");
            username = scanner.nextLine();

            System.out.print("Enter password (at least 8 characters, uppercase, lowercase, number, special character): ");
            password = scanner.nextLine();

            System.out.print("Enter first name: ");
            firstName = scanner.nextLine();

            System.out.print("Enter last name: ");
            lastName = scanner.nextLine();

            System.out.println(registerUser(username, password, firstName, lastName));

        } while (!isValidRegistration(username, password)); // Repeat until valid registration

        // Login loop
        String storedUsername = username;
        String storedPassword = password; // Simulate storing registered credentials (replace with secure storage)
        boolean loggedIn = false;

        do {
            System.out.println("\n** Login **");

            System.out.print("Enter username: ");
            username = scanner.nextLine();

            System.out.print("Enter password: ");
            password = scanner.nextLine();

            loggedIn = loginUser(username, password, storedUsername, storedPassword);

            System.out.println(loggedIn ? "Login successful!" : "Login failed. Please try again.");

        } while (!loggedIn); // Repeat until successful login

        System.out.println("\nWelcome, " + firstName + " " + lastName + "!");

        scanner.close();
    }

    public static String registerUser(String username, String password, String firstName, String lastName) {
        StringBuilder message = new StringBuilder();

        if (isValidUsername(username)) {
            message.append("Username successfully captured.\n");
        } else {
            message.append("Username is invalid. Please use alphanumeric characters only, between 5 and 15 characters long.\n");
        }

        if (isValidPassword(password)) {
            message.append("Password successfully captured.");
        } else {
            message.append("Password is weak. Please ensure it's at least 8 characters long, containing an uppercase letter, a lowercase letter, a number, and a special character.\n");
        }

        return message.toString();
    }

    public static boolean isValidUsername(String username) {
        return username.matches("^[a-zA-Z0-9]{5,15}$"); // Regular expression for username format
    }

    public static boolean isValidPassword(String password) {
        boolean hasUppercase = false;
        boolean hasLowercase = false;
        boolean hasNumber = false;
        boolean hasSpecialChar = false;

        if (password.length() >= 8) {
            for (char current : password.toCharArray()) {
                if (Character.isUpperCase(current)) {
                    hasUppercase = true;
                } else if (Character.isLowerCase(current)) {
                    hasLowercase = true;
                } else if (Character.isDigit(current)) {
                    hasNumber = true;
                } else if (!Character.isLetterOrDigit(current)) {
                    hasSpecialChar = true;
                }
            }
        }

        return hasUppercase && hasLowercase && hasNumber && hasSpecialChar;
    }

    public static boolean loginUser(String username, String password, String storedUsername, String storedPassword) {
        return username.equals(storedUsername) && password.equals(storedPassword);
    }

    public static boolean isValidRegistration(String username, String password) {
        return isValidUsername(username) && isValidPassword(password);
    }
}
